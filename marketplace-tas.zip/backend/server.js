import express from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";
import connectDB from "./config/db.js";
import productRoutes from "./routes/productRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import xss from "xss-clean";
import mongoSanitize from "express-mongo-sanitize";

dotenv.config();
connectDB();

const app = express();
app.use(helmet());
app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));
app.use(xss());
app.use(mongoSanitize());

const CLIENT_URL = process.env.CLIENT_URL || "*";
app.use(cors({
  origin: CLIENT_URL,
  methods: ["GET","POST","PUT","DELETE","OPTIONS"],
  credentials: true
}));

const limiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 120,
  message: { error: "Too many requests, try again later." }
});
app.use(limiter);

app.use("/api/products", productRoutes);
app.use("/api/auth", authRoutes);

app.get("/health", (req, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT} - NODE_ENV=${process.env.NODE_ENV}`);
});
