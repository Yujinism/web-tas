import axios from "axios";

const API_HOST = import.meta.env.VITE_API_BASE || "http://localhost:5000";
const client = axios.create({
  baseURL: API_HOST + "/api",
  headers: { "Content-Type": "application/json" }
});
export default client;
