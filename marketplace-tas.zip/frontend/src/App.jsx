import React from "react";
import ProductGrid from "./components/ProductGrid";

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Marketplace Tas</h1>
      </header>
      <main className="max-w-6xl mx-auto">
        <ProductGrid />
      </main>
    </div>
  );
}
