import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import api from "../utils/api";

export default function ProductGrid(){
  const [products, setProducts] = useState([]);
  useEffect(()=>{
    api.get("/products").then(r=>setProducts(r.data)).catch(()=>setProducts([]));
  },[]);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.length === 0 && (
        <div className="col-span-full text-center text-gray-500">No products yet.</div>
      )}
      {products.map(p=>(
        <motion.div key={p._id} className="bg-white p-4 rounded-lg shadow" whileHover={{ scale: 1.03 }}>
          <div className="h-40 bg-gray-100 rounded overflow-hidden flex items-center justify-center">
            {p.image ? <img src={p.image} alt={p.name} className="h-full object-cover" /> : <span className="text-gray-400">No image</span>}
          </div>
          <h3 className="mt-3 font-semibold">{p.name}</h3>
          <p className="text-pink-600 font-bold">${p.price}</p>
        </motion.div>
      ))}
    </div>
  );
}
