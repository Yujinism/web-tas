# Marketplace Tas (Deploy-ready template)

This zip contains a minimal but production-oriented template:
- backend/: Node + Express + MongoDB (ready for Render or Docker)
- frontend/: Vite + React (ready for Vercel)

Follow the previous instructions in the UI to set environment variables, deploy backend (Render) and frontend (Vercel), and replace placeholders such as YOUR-RENDER-BACKEND-URL.

Don't commit `.env` files. Use service environment settings.
